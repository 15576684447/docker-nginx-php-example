<?php
define("VER","VHR6000D_r132_v2.1");
?>