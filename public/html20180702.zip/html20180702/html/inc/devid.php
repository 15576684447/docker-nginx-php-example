<?php
define("DEVID","VHR6000D1707052240");
?>