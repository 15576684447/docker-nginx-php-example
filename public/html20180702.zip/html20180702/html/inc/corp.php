<?php
define("CORP","HZYYKJ");
?>